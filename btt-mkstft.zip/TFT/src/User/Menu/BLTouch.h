#ifndef _BLTOUCH_H_
#define _BLTOUCH_H_

#ifdef __cplusplus
extern "C" {
#endif

void menuBLTouch(void);

#ifdef __cplusplus
}
#endif

#endif

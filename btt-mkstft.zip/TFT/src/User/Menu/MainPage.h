#ifndef _MAINPAGE_H_
#define _MAINPAGE_H_

#ifdef __cplusplus
extern "C" {
#endif

void unifiedMenu(void);
void classicMenu(void);

#ifdef __cplusplus
}
#endif

#endif

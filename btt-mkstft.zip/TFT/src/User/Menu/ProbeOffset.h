#ifndef _PROBEOFFSET_H_
#define _PROBEOFFSET_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

void menuProbeOffset(void);

#ifdef __cplusplus
}
#endif

#endif

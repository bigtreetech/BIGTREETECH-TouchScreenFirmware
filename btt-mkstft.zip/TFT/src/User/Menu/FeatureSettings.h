#ifndef _FEATURE_SETTINGS_H_
#define _FEATURE_SETTINGS_H_

#ifdef __cplusplus
extern "C" {
#endif

void menuFeatureSettings(void);
void resetSettings(void);

#ifdef __cplusplus
}
#endif

#endif

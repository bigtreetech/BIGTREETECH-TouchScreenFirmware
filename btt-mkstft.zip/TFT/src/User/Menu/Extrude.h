#ifndef _EXTRUDE_H_
#define _EXTRUDE_H_

#ifdef __cplusplus
extern "C" {
#endif

extern const char* tool_change[];
extern const char* extruderDisplayID[];

void menuExtrude(void);

#ifdef __cplusplus
}
#endif

#endif

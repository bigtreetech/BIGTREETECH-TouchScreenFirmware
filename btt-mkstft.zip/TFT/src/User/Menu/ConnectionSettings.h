#ifndef _CONNECTION_SETTINGS_H_
#define _CONNECTION_SETTINGS_H_

#ifdef __cplusplus
extern "C" {
#endif

void menuConnectionSettings(void);

#ifdef __cplusplus
}
#endif

#endif

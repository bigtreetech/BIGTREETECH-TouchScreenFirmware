#ifndef _UNIFIEDMOVE_H_
#define _UNIFIEDMOVE_H_

#ifdef __cplusplus
extern "C" {
#endif

void menuUnifiedMove(void);

#ifdef __cplusplus
}
#endif

#endif
